# Attribution and modification notice

Tiers: Copyright (C) 2025 Flavio6561 and contributors.
Upstream: https://github.com/PvPTiers/Tiers
Base branch: 1.21.11, commit abce7e1bc6ed67501e019c72602fa3c82143d023.

MCPvP Tier Tagger is an independent adaptation made for augumental on October 7, 2026. It changes tier lookups to the configurable MCPvP leaderboard endpoint, adds an optional configurable MCTiers backup, uses Mojang for offline name resolution, adds middle tiers and MCPvP kits, adds API settings and kit pagination, and includes verification scripts. Original GUI, assets and name tag integration are retained and adapted. It is not endorsed by PvPTiers or MCPvP.

The source and binary are distributed under the GNU General Public License, version 3 or (at your option) any later version. The original license and notices are retained. Corresponding source includes all modified Java files, resources, Gradle configuration, wrapper and tests.
