// MCPvP Tier Tagger fork: added October 7, 2026. See NOTICE.md.
package com.tiers.screens;

import com.tiers.TiersClient;
import com.tiers.api.ApiConfig;
import com.tiers.api.TierApi;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** API settings added to the upstream Tiers GUI for the MCPvP fork. */
public final class ApiSettingsScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget primary, backup;
    private boolean backupEnabled;
    private String error = "";
    public ApiSettingsScreen(Screen parent) { super(Text.literal("MCPvP API settings")); this.parent = parent; }
    @Override protected void init() {
        int x = width / 2 - 150, y = height / 2 - 65;
        primary = new TextFieldWidget(textRenderer, x, y, 300, 20, Text.literal("Primary URL"));
        primary.setMaxLength(2048); primary.setText(ApiConfig.current.primaryUrl); addDrawableChild(primary);
        backup = new TextFieldWidget(textRenderer, x, y + 45, 300, 20, Text.literal("Backup URL with {uuid}"));
        backup.setMaxLength(2048); backup.setText(ApiConfig.current.backupUrl); addDrawableChild(backup);
        backupEnabled = ApiConfig.current.backupEnabled;
        addDrawableChild(ButtonWidget.builder(Text.literal("Backup: " + (backupEnabled ? "ON" : "OFF")), b -> {
            backupEnabled = !backupEnabled; b.setMessage(Text.literal("Backup: " + (backupEnabled ? "ON" : "OFF")));
        }).dimensions(x, y + 75, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> save()).dimensions(x + 155, y + 75, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x, y + 105, 300, 20).build());
    }
    private void save() {
        ApiConfig previous = ApiConfig.current;
        try {
            ApiConfig cfg = new ApiConfig(); cfg.primaryUrl = primary.getText().trim(); cfg.backupUrl = backup.getText().trim();
            cfg.backupEnabled = backupEnabled; cfg.timeoutSeconds = previous.timeoutSeconds; cfg.cacheMinutes = previous.cacheMinutes;
            cfg.validate(); ApiConfig.current = cfg; ApiConfig.save();
            TiersClient.tierApi = new TierApi(TiersClient.httpClient, cfg);
            TiersClient.clearCache(false); close();
        } catch (Exception e) { ApiConfig.current = previous; error = e.getMessage(); }
    }
    @Override public void render(DrawContext context, int mx, int my, float delta) {
        super.render(context, mx, my, delta);
        int x = width / 2 - 150, y = height / 2 - 65;
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, y - 40, 0xffffffff);
        context.drawTextWithShadow(textRenderer, "Primary MCPvP URL", x, y - 12, 0xffffffff);
        context.drawTextWithShadow(textRenderer, "Backup URL ({uuid} is replaced automatically)", x, y + 33, 0xffffffff);
        context.drawCenteredTextWithShadow(textRenderer, error, width / 2, y + 133, 0xffff5555);
    }
    @Override public void close() { client.setScreen(parent); }
}
