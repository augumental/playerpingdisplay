// MCPvP Tier Tagger fork: modified October 7, 2026. See NOTICE.md.
package com.tiers.profile.types;

import com.tiers.misc.Mode;
import com.tiers.profile.GameMode;
import net.minecraft.util.Identifier;

public class PvPTiersProfile extends SuperProfile {
    public static final Identifier PVPTIERS_IMAGE = Identifier.of("minecraft", "textures/pvptiers_logo.png");

    public PvPTiersProfile(String apiUrl, String uuid, String extra) {
        super();
        addGamemodes();
        buildRequest(apiUrl, uuid, extra);
    }

    public PvPTiersProfile(String json) {
        super();
        addGamemodes();
        parseJson(json);
    }

    private void addGamemodes() {
        gameModes.add(new GameMode(Mode.PVPTIERS_CRYSTAL, "crystal"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SWORD, "sword"));
        gameModes.add(new GameMode(Mode.PVPTIERS_UHC, "uhc"));
        gameModes.add(new GameMode(Mode.PVPTIERS_POT, "pot"));
        gameModes.add(new GameMode(Mode.PVPTIERS_NETH_POT, "neth_pot"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SMP, "smp"));
        gameModes.add(new GameMode(Mode.PVPTIERS_AXE, "axe"));
        gameModes.add(new GameMode(Mode.PVPTIERS_MACE, "mace"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SHIELD, "shield"));
        gameModes.add(new GameMode(Mode.PVPTIERS_EARLY_GAME, "early-game"));
        gameModes.add(new GameMode(Mode.PVPTIERS_LATE_GAME, "late-game"));
        gameModes.add(new GameMode(Mode.PVPTIERS_END_GAME, "end-game"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SPEAR, "spear"));
        gameModes.add(new GameMode(Mode.PVPTIERS_DIAMOND_SMP, "diamond-smp"));
        gameModes.add(new GameMode(Mode.PVPTIERS_CART, "cart"));
        gameModes.add(new GameMode(Mode.PVPTIERS_CREEPER, "creeper"));
        gameModes.add(new GameMode(Mode.PVPTIERS_BOW, "bow"));

    }
}