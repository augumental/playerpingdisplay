package com.tiers.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;

/** MCPvP fork configuration; modified October 2026. */
public final class ApiConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("mcpvp-tier-tagger-api.json"); }
    public static volatile ApiConfig current = new ApiConfig();
    public String primaryUrl = "https://www.mcpvp.com/tiers/data";
    public String backupUrl = "https://mctiers.com/api/profile/{uuid}";
    public boolean backupEnabled = true;
    public int timeoutSeconds = 8;
    public int cacheMinutes = 10;

    public static void load() {
        try {
            if (Files.exists(file())) {
                ApiConfig loaded = GSON.fromJson(Files.readString(file()), ApiConfig.class);
                if (loaded != null) { loaded.validate(); current = loaded; }
            }
            save();
        } catch (Exception e) {
            com.tiers.TiersClient.LOGGER.warn("MCPvP API configuration could not be loaded; using defaults", e);
        }
    }
    public void validate() {
        validateUrl(primaryUrl);
        validateUrl(backupUrl.replace("{uuid}", "00000000000000000000000000000000"));
        timeoutSeconds = Math.clamp(timeoutSeconds, 2, 30);
        cacheMinutes = Math.clamp(cacheMinutes, 1, 60);
    }
    private static void validateUrl(String value) {
        URI uri = URI.create(value);
        if (!("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) || uri.getHost() == null)
            throw new IllegalArgumentException("Enter an HTTP or HTTPS URL");
    }
    public static void save() throws java.io.IOException {
        Files.createDirectories(file().getParent());
        Files.writeString(file(), GSON.toJson(current));
    }
}
