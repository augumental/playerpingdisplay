// MCPvP Tier Tagger fork: added October 7, 2026. See NOTICE.md.
package com.tiers.api;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Asynchronous, shared paginated MCPvP index with optional MCTiers fallback. */
public final class TierApi {
    public record Result(JsonObject profile, String source) {}
    private final HttpClient client;
    private final ApiConfig config;
    private final Map<String, JsonObject> players = new ConcurrentHashMap<>();
    private final Map<String, Cached> backupCache = new ConcurrentHashMap<>();
    private CompletableFuture<Void> page;
    private int offset;
    private boolean complete;
    private long expires;
    private record Cached(Result result, long expires) {}

    public TierApi(HttpClient client, ApiConfig config) { this.client = client; this.config = config; }
    public CompletableFuture<JsonObject> resolveName(String name) {
        if (!name.matches("[A-Za-z0-9_]{3,16}")) return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid username"));
        return get("https://api.mojang.com/users/profiles/minecraft/" + name).thenApply(json -> {
            if (!json.isJsonObject() || !json.getAsJsonObject().has("id")) throw new CompletionException(new IllegalArgumentException("Player not found"));
            return json.getAsJsonObject();
        });
    }
    public CompletableFuture<Result> lookup(String uuid, String name) {
        String key = uuid.replace("-", "").toLowerCase(Locale.ROOT);
        Cached cached = backupCache.get(key);
        if (cached != null && cached.expires > System.currentTimeMillis()) return CompletableFuture.completedFuture(cached.result);
        return primary(key, name, 0, System.currentTimeMillis() + 30_000).thenApply(profile -> profile == null ? null : normalize(profile, name)).orTimeout(30, TimeUnit.SECONDS).handle((profile, error) -> {
            if (error == null && profile != null) return CompletableFuture.completedFuture(new Result(profile, "MCPvP"));
            if (!config.backupEnabled) {
                if (error != null) return CompletableFuture.<Result>failedFuture(error);
                return CompletableFuture.completedFuture(new Result(null, "MCPvP"));
            }
            String url = config.backupUrl.contains("{uuid}") ? config.backupUrl.replace("{uuid}", key) : config.backupUrl + key;
            return get(url).thenApply(json -> {
                JsonObject profileData = find(json, key, name);
                Result result = new Result(profileData == null ? null : normalize(profileData, name), "MCTiers backup");
                backupCache.put(key, new Cached(result, System.currentTimeMillis() + config.cacheMinutes * 60_000L));
                return result;
            });
        }).thenCompose(future -> future);
    }
    private synchronized CompletableFuture<JsonObject> primary(String uuid, String name, int pages, long deadline) {
        if (System.currentTimeMillis() >= expires && (page == null || page.isDone())) {
            players.clear(); offset = 0; complete = false; page = null;
            expires = System.currentTimeMillis() + config.cacheMinutes * 60_000L;
        }
        JsonObject found = players.get(uuid);
        // Name fallback accommodates leaderboard rows with no UUID, but never a different UUID.
        if (found == null) found = players.get("name:" + name.toLowerCase(Locale.ROOT));
        if (found != null) return CompletableFuture.completedFuture(found);
        if (complete) return CompletableFuture.completedFuture(null);
        if (System.currentTimeMillis() >= deadline) return CompletableFuture.failedFuture(new TimeoutException("Primary lookup timed out"));
        if (pages >= 500) return CompletableFuture.failedFuture(new IllegalStateException("Leaderboard pagination limit reached"));
        if (page == null || page.isDone()) {
            int requestedOffset = offset;
            String separator = config.primaryUrl.contains("?") ? "&" : "?";
            String url = config.primaryUrl + separator + "offset=" + requestedOffset + "&limit=100&include_retired=1";
            page = get(url).thenAccept(json -> {
                if (!json.isJsonObject()) throw new IllegalArgumentException("Primary API did not return an object");
                JsonObject root = json.getAsJsonObject();
                if (!root.has("players") || !root.get("players").isJsonArray()) throw new IllegalArgumentException("Primary API is missing players");
                for (JsonElement entry : root.getAsJsonArray("players")) {
                    if (!entry.isJsonObject()) continue;
                    JsonObject row = entry.getAsJsonObject();
                    String id = string(row, "uuid", "").replace("-", "").toLowerCase(Locale.ROOT);
                    if (!id.isEmpty()) players.put(id, row);
                    else players.put("name:" + string(row, "name", "").toLowerCase(Locale.ROOT), row);
                }
                synchronized (this) {
                    complete = !root.has("hasMore") || !root.get("hasMore").getAsBoolean();
                    int next = root.has("nextOffset") && !root.get("nextOffset").isJsonNull() ? root.get("nextOffset").getAsInt() : requestedOffset + root.getAsJsonArray("players").size();
                    if (!complete && next <= requestedOffset) throw new IllegalArgumentException("Primary API pagination did not advance");
                    offset = next;
                }
            });
        }
        return page.thenCompose(ignored -> primary(uuid, name, pages + 1, deadline));
    }
    private CompletableFuture<JsonElement> get(String url) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(config.timeoutSeconds))
                .header("User-Agent", "MCPvP-Tier-Tagger/1.0 (Fabric; based on PvPTiers/Tiers)")
                .header("Accept", "application/json").GET().build();
            return client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(response -> {
                if (response.statusCode() == 404 || response.statusCode() == 204) return JsonNull.INSTANCE;
                if (response.statusCode() != 200) throw new CompletionException(new java.io.IOException("Tier API returned HTTP " + response.statusCode()));
                return JsonParser.parseString(response.body());
            });
        } catch (Exception e) { return CompletableFuture.failedFuture(e); }
    }
    private static JsonObject find(JsonElement json, String uuid, String name) {
        if (json == null || json.isJsonNull()) return null;
        if (!json.isJsonObject()) throw new IllegalArgumentException("Backup API did not return a profile object");
        JsonObject root = json.getAsJsonObject();
        if (root.has("data") && root.get("data").isJsonObject()) root = root.getAsJsonObject("data");
        if (root.has("rankings") || root.has("kitRanks")) return root;
        if (root.has("players") && root.get("players").isJsonArray()) {
            for (JsonElement entry : root.getAsJsonArray("players")) {
                JsonObject row = entry.getAsJsonObject();
                if (string(row, "uuid", "").replace("-", "").equalsIgnoreCase(uuid) || string(row, "name", "").equalsIgnoreCase(name)) return row;
            }
            return null;
        }
        throw new IllegalArgumentException("Backup API is missing rankings");
    }
    public static JsonObject normalize(JsonObject raw, String name) {
        JsonObject out = new JsonObject();
        out.addProperty("name", string(raw, "name", name));
        out.addProperty("region", string(raw, "region", "Unknown"));
        out.addProperty("points", number(raw, "points", 0));
        out.addProperty("overall", number(raw, raw.has("overall") ? "overall" : "rank", 0));
        JsonObject ranks = new JsonObject();
        if (raw.has("kitRanks") && raw.get("kitRanks").isJsonObject()) {
            JsonObject peaks = raw.has("kitPeakRanks") && raw.get("kitPeakRanks").isJsonObject() ? raw.getAsJsonObject("kitPeakRanks") : new JsonObject();
            JsonObject retired = raw.has("kitRetired") && raw.get("kitRetired").isJsonObject() ? raw.getAsJsonObject("kitRetired") : new JsonObject();
            for (var entry : raw.getAsJsonObject("kitRanks").entrySet()) {
                String rank = entry.getValue().isJsonNull() ? "" : entry.getValue().getAsString().toUpperCase(Locale.ROOT);
                if (!rank.matches("R?[HML]T[1-5]")) continue;
                JsonObject normalized = tier(rank);
                String peak = string(peaks, entry.getKey(), rank).toUpperCase(Locale.ROOT);
                JsonObject peakData = peak.matches("R?[HML]T[1-5]") ? tier(peak) : normalized;
                normalized.add("peak_tier", peakData.get("tier")); normalized.add("peak_pos", peakData.get("pos"));
                normalized.addProperty("retired", rank.startsWith("R") || (retired.has(entry.getKey()) && retired.get(entry.getKey()).getAsBoolean()));
                ranks.add(alias(entry.getKey()), normalized);
            }
        } else if (raw.has("rankings") && raw.get("rankings").isJsonObject()) {
            for (var entry : raw.getAsJsonObject("rankings").entrySet()) {
                if (!entry.getValue().isJsonObject()) continue;
                JsonObject data = entry.getValue().getAsJsonObject().deepCopy();
                if (!data.has("tier") || data.get("tier").isJsonNull() || !data.has("pos") || data.get("pos").isJsonNull()) continue;
                if (!data.has("attained") || data.get("attained").isJsonNull()) data.addProperty("attained", 0);
                if (!data.has("retired") || data.get("retired").isJsonNull()) data.addProperty("retired", false);
                if (!data.has("peak_tier")) data.add("peak_tier", JsonNull.INSTANCE);
                if (!data.has("peak_pos")) data.add("peak_pos", JsonNull.INSTANCE);
                ranks.add(alias(entry.getKey()), data);
            }
        } else throw new IllegalArgumentException("Profile is missing tier rankings");
        out.add("rankings", ranks); return out;
    }
    private static JsonObject tier(String label) {
        label = label.replace("R", "");
        JsonObject obj = new JsonObject(); obj.addProperty("tier", Integer.parseInt(label.substring(2)));
        obj.addProperty("pos", label.charAt(0) == 'H' ? 0 : label.charAt(0) == 'M' ? 2 : 1);
        obj.addProperty("attained", 0); return obj;
    }
    private static String alias(String key) {
        return switch (key) { case "vanilla" -> "crystal"; case "nethop", "neth_op", "netherite-pot" -> "neth_pot"; default -> key; };
    }
    private static double number(JsonObject obj, String key, double fallback) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsDouble() : fallback;
    }
    private static String string(JsonObject obj, String key, String fallback) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsString() : fallback;
    }
}
