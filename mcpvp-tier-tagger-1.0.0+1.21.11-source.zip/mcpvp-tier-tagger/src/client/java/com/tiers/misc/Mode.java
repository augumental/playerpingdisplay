// MCPvP Tier Tagger fork: modified October 7, 2026. See NOTICE.md.
package com.tiers.misc;

import com.tiers.textures.Icons;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Colors;
import net.minecraft.util.Identifier;

import java.util.Arrays;
import java.util.Locale;

public enum Mode {
    MCTIERS_VANILLA(Category.MCTIERS, "\uF000", "Vanilla"),
    MCTIERS_UHC(Category.MCTIERS, "\uF001", "UHC"),
    MCTIERS_POT(Category.MCTIERS, "\uF002", "Pot"),
    MCTIERS_NETH_OP(Category.MCTIERS, "\uF003", "Neth Op"),
    MCTIERS_SMP(Category.MCTIERS, "\uF004", "Smp"),
    MCTIERS_SWORD(Category.MCTIERS, "\uF005", "Sword"),
    MCTIERS_AXE(Category.MCTIERS, "\uF006", "Axe"),
    MCTIERS_MACE(Category.MCTIERS, "\uF007", "Mace"),

    PVPTIERS_CRYSTAL(Category.PVPTIERS, "\uF000", "Crystal"),
    PVPTIERS_SWORD(Category.PVPTIERS, "\uF005", "Sword"),
    PVPTIERS_UHC(Category.PVPTIERS, "\uF001", "UHC"),
    PVPTIERS_POT(Category.PVPTIERS, "\uF002", "Pot"),
    PVPTIERS_NETH_POT(Category.PVPTIERS, "\uF003", "Neth Pot"),
    PVPTIERS_SMP(Category.PVPTIERS, "\uF004", "Smp"),
    PVPTIERS_AXE(Category.PVPTIERS, "\uF006", "Axe"),
    PVPTIERS_MACE(Category.PVPTIERS, "\uF007", "Mace"),

    PVPTIERS_SHIELD(Category.PVPTIERS, "Sh", "Shield"),
    PVPTIERS_EARLY_GAME(Category.PVPTIERS, "EG", "Early Game"),
    PVPTIERS_LATE_GAME(Category.PVPTIERS, "LG", "Late Game"),
    PVPTIERS_END_GAME(Category.PVPTIERS, "En", "End Game"),
    PVPTIERS_SPEAR(Category.PVPTIERS, "Sp", "Spear"),
    PVPTIERS_DIAMOND_SMP(Category.PVPTIERS, "DS", "Diamond SMP"),
    PVPTIERS_CART(Category.PVPTIERS, "Ca", "Cart"),
    PVPTIERS_CREEPER(Category.PVPTIERS, "Cr", "Creeper"),
    PVPTIERS_BOW(Category.PVPTIERS, "Bw", "Bow"),

    SUBTIERS_MINECART(Category.SUBTIERS, "\uF000", "Minecart"),
    SUBTIERS_DIAMOND_VANILLA(Category.SUBTIERS, "\uF001", "Diamond Vanilla"),
    SUBTIERS_DEBUFF(Category.SUBTIERS, "\uF002", "DeBuff"),
    SUBTIERS_ELYTRA(Category.SUBTIERS, "\uF003", "Elytra"),
    SUBTIERS_SPEED(Category.SUBTIERS, "\uF004", "Speed"),
    SUBTIERS_CREEPER(Category.SUBTIERS, "\uF005", "Creeper"),
    SUBTIERS_MANHUNT(Category.SUBTIERS, "\uF006", "Manhunt"),
    SUBTIERS_DIAMOND_SMP(Category.SUBTIERS, "\uF007", "Diamond Smp"),
    SUBTIERS_BOW(Category.SUBTIERS, "\uF008", "Bow"),
    SUBTIERS_BED(Category.SUBTIERS, "\uF009", "Bed"),
    SUBTIERS_OG_VANILLA(Category.SUBTIERS, "\uF00A", "OG Vanilla"),
    SUBTIERS_TRIDENT(Category.SUBTIERS, "\uF00B", "Trident");

    private final Category category;
    private final String unicode;
    private final String label;

    Mode(Category category, String unicode, String label) {
        this.category = category;
        this.unicode = unicode;
        this.label = label;
    }

    public enum Category {
        MCTIERS,
        PVPTIERS,
        SUBTIERS
    }

    public Text getIcon() {
        if (unicode.length() > 1) return Text.literal(unicode).withColor(Colors.WHITE);
        Identifier identifier = switch (category) {
            case MCTIERS -> Icons.identifierMCTiers;
            case PVPTIERS -> Icons.identifierPvPTiers;
            case SUBTIERS -> Icons.identifierSubtiers;
        };
        return Text.literal(unicode).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(identifier)).withColor(Colors.WHITE));
    }

    public Text getIconTag() {
        if (unicode.length() > 1) return Text.literal(label).withColor(Colors.WHITE);
        Identifier identifier = switch (category) {
            case MCTIERS -> Icons.identifierMCTiersTags;
            case PVPTIERS -> Icons.identifierPvPTiersTags;
            case SUBTIERS -> Icons.identifierSubtiersTags;
        };
        return Text.literal(unicode).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(identifier)).withColor(Colors.WHITE));
    }

    public Text getTextLabel() {
        return Icons.colorText(label, name().toLowerCase(Locale.ROOT));
    }

    public static Mode[] getMCTiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("MCTIERS")).toArray(Mode[]::new);
    }

    public static Mode[] getPvPTiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("PVPTIERS")).toArray(Mode[]::new);
    }

    public static Mode[] getSubtiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("SUBTIERS")).toArray(Mode[]::new);
    }
}