package com.tiers;

import com.google.gson.*;
import com.mojang.brigadier.CommandDispatcher;
import com.tiers.api.*;
import com.tiers.profile.*;
import com.tiers.screens.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.util.ScreenshotRecorder;
import java.nio.file.*;

public final class TierGuiSmoke implements ClientModInitializer {
    private int phase, ticks;
    private PlayerProfile profile;
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static ButtonWidget button(Screen screen, String label) {
        return screen.children().stream().filter(e -> e instanceof ButtonWidget).map(e -> (ButtonWidget)e).filter(b -> b.getMessage().getString().equals(label)).findFirst().orElseThrow();
    }
    private static void press(Screen screen, String label) { button(screen, label).onPress(new MouseInput(0, 0)); }
    @Override public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.currentScreen == null || client.getOverlay() != null || ++ticks < 25) return;
            ticks = 0;
            try {
                switch (phase++) {
                    case 0 -> {
                        client.options.getGuiScale().setValue(2); client.onResolutionChanged();
                        JsonObject raw = JsonParser.parseString(Files.readString(Path.of("../../tests/fixtures/mcpvp.json"))).getAsJsonObject().getAsJsonArray("players").get(0).getAsJsonObject();
                        JsonObject data = TierApi.normalize(raw, "AXIMITY");
                        profile = new PlayerProfile("{\"name\":\"AXIMITY\",\"id\":\"37bba5ee9e644d5e975cffe1f139b24e\"}", data.toString());
                        profile.targetName = profile.name; profile.inGameName = profile.name;
                        profile.numberOfImageRequests = 6;
                        Files.createDirectories(Path.of("cache/tiers/players"));
                        Files.copy(Path.of("cache/tiers/06ec3577329945fabbdf613b1f86c8ab.png"), Path.of("cache/tiers/players/" + profile.uuid + ".png"), StandardCopyOption.REPLACE_EXISTING);
                        profile.imageSaved = 1;
                        TiersClient.playerProfiles.add(profile); TiersClient.readyPlayerProfiles.put(profile.name, profile);
                        TiersClient.activePvPTiersMode = com.tiers.misc.Mode.PVPTIERS_EARLY_GAME;
                        profile.updateAppendingText();
                        check(profile.getFullName().getString().contains("MT1"), "Middle tier name tag");
                        check(profile.getFullName(net.minecraft.text.Text.literal("AXIMITY")).getString().contains("MT1"), "Name tag formatting preserves name");
                        CommandDispatcher<FabricClientCommandSource> dispatcher = new CommandDispatcher<>();
                        ClientCommandRegistrationCallback.EVENT.invoker().register(dispatcher, null);
                        dispatcher.execute("tiers AXIMITY", null);
                    }
                    case 1 -> { check(client.currentScreen instanceof PlayerSearchResultScreen, "Command opens original GUI"); }
                    case 2 -> {
                        var fields = client.currentScreen.children().stream().filter(e -> e instanceof TextWidget).map(e -> (TextWidget)e).toList();
                        check(fields.stream().anyMatch(w -> w.getMessage().getString().equals("HT1")), "Tier widgets rendered");
                        ScreenshotRecorder.saveScreenshot(new java.io.File("."), "tiers-profile.png", client.getFramebuffer(), 1, ignored -> {});
                        press(client.currentScreen, "Next kits");
                    }
                    case 3 -> {}
                    case 4 -> {
                        var fields = client.currentScreen.children().stream().filter(e -> e instanceof TextWidget).map(e -> (TextWidget)e).toList();
                        check(fields.stream().anyMatch(w -> w.getMessage().getString().equals("Sp")), "Second page includes MCPvP extra kits");
                        ScreenshotRecorder.saveScreenshot(new java.io.File("."), "tiers-extra-kits.png", client.getFramebuffer(), 1, ignored -> {});
                        TiersClient.tiersCommand("-api");
                    }
                    case 5 -> { check(client.currentScreen instanceof ApiSettingsScreen, "API command opens settings"); press(client.currentScreen, "Backup: ON"); }
                    case 6 -> {
                        check(button(client.currentScreen, "Backup: OFF") != null, "Backup toggle");
                        var fields = client.currentScreen.children().stream().filter(e -> e instanceof TextFieldWidget).map(e -> (TextFieldWidget)e).toList();
                        fields.get(0).setText("ftp://invalid"); press(client.currentScreen, "Save");
                        check(client.currentScreen instanceof ApiSettingsScreen, "Invalid URL keeps settings open");
                        fields.get(0).setText("https://www.mcpvp.com/tiers/data"); press(client.currentScreen, "Save");
                        check(!ApiConfig.current.backupEnabled, "Backup setting persisted");
                        ApiConfig.load(); check(!ApiConfig.current.backupEnabled, "API config round trip");
                        TiersClient.tiersCommand("-config");
                    }
                    case 7 -> { check(client.currentScreen instanceof ConfigScreen, "Original config GUI"); press(client.currentScreen, "API settings"); }
                    case 8 -> { check(client.currentScreen instanceof ApiSettingsScreen, "API settings navigation"); System.out.println("TIER_GUI_SMOKE_PASSED"); client.scheduleStop(); }
                }
            } catch (Throwable e) { e.printStackTrace(); System.out.println("TIER_GUI_SMOKE_FAILED"); System.exit(1); }
        });
    }
}
