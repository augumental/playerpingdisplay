package com.tiers;

import com.google.gson.*;
import com.sun.net.httpserver.HttpServer;
import com.tiers.api.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class TierApiTests {
    private static void check(boolean value, String what) { if (!value) throw new AssertionError(what); }
    private static void verifyLiveProfile(TierApi.Result result) {
        check(result.profile() != null && result.source().equals("MCPvP"), "Live primary tier lookup");
        check(result.profile().getAsJsonObject("rankings").has("shield"), "Live Shield tier data");
    }
    public static void main(String[] args) throws Exception {
        JsonObject live = JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject();
        JsonObject aximity = live.getAsJsonArray("players").get(0).getAsJsonObject();
        JsonObject normalized = TierApi.normalize(aximity, "AXIMITY");
        check(normalized.getAsJsonObject("rankings").getAsJsonObject("early-game").get("pos").getAsInt() == 2, "MT preserved");
        check(normalized.getAsJsonObject("rankings").has("shield"), "Shield retained");
        check(normalized.getAsJsonObject("rankings").has("neth_pot"), "Netherite Pot alias");
        check(normalized.get("points").getAsDouble() == aximity.get("points").getAsDouble(), "Fractional overall points");
        AtomicInteger requests = new AtomicInteger(), backups = new AtomicInteger();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/data", exchange -> {
            requests.incrementAndGet();
            String offset = exchange.getRequestURI().getQuery();
            String body = offset.contains("offset=0&") ? "{\"players\":[],\"hasMore\":true,\"nextOffset\":100}" : "{\"players\":[" + aximity + "],\"hasMore\":false,\"nextOffset\":101}";
            byte[] data = body.getBytes(StandardCharsets.UTF_8); exchange.sendResponseHeaders(200, data.length); exchange.getResponseBody().write(data); exchange.close();
        });
        server.createContext("/fail", e -> { e.sendResponseHeaders(503, -1); e.close(); });
        server.createContext("/bad", e -> { byte[] data = "<html>bad</html>".getBytes(); e.sendResponseHeaders(200, data.length); e.getResponseBody().write(data); e.close(); });
        server.createContext("/backup", e -> { backups.incrementAndGet(); byte[] data = normalized.toString().getBytes(); e.sendResponseHeaders(200, data.length); e.getResponseBody().write(data); e.close(); });
        server.start();
        try {
            String base = "http://127.0.0.1:" + server.getAddress().getPort();
            ApiConfig cfg = new ApiConfig(); cfg.primaryUrl = base + "/data"; cfg.backupUrl = base + "/backup/{uuid}";
            var client = HttpClient.newHttpClient(); var api = new TierApi(client, cfg);
            var a = api.lookup(aximity.get("uuid").getAsString(), "AXIMITY"); var b = api.lookup(aximity.get("uuid").getAsString(), "AXIMITY");
            check(a.get(5, TimeUnit.SECONDS).source().equals("MCPvP") && b.get(5, TimeUnit.SECONDS).profile() != null, "Primary pagination and concurrent lookups");
            check(requests.get() == 2 && backups.get() == 0, "Shared pages and primary preferred");
            api.lookup(aximity.get("uuid").getAsString(), "AXIMITY").get(); check(requests.get() == 2, "Positive cache");
            cfg.primaryUrl = base + "/fail"; api = new TierApi(client, cfg);
            check(api.lookup(aximity.get("uuid").getAsString(), "AXIMITY").get().source().equals("MCTiers backup"), "HTTP error fallback");
            cfg.primaryUrl = base + "/bad"; api = new TierApi(client, cfg);
            check(api.lookup(aximity.get("uuid").getAsString(), "AXIMITY").get().source().equals("MCTiers backup"), "Malformed response fallback");
            cfg.primaryUrl = base + "/data"; api = new TierApi(client, cfg);
            check(api.lookup("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Unranked").get().source().equals("MCTiers backup"), "Missing primary player fallback");
            int count = backups.get(); cfg.backupEnabled = false; cfg.primaryUrl = base + "/fail"; api = new TierApi(client, cfg);
            try { api.lookup("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Unranked").get(); throw new AssertionError("Error must surface"); } catch (ExecutionException expected) {}
            check(backups.get() == count, "Disabled backup sends no requests");
            cfg.primaryUrl = base + "/data"; api = new TierApi(client, cfg);
            check(api.lookup("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Unranked").get().profile() == null, "Unranked stays unranked");
            JsonObject retired = aximity.deepCopy(); retired.getAsJsonObject("kitRanks").addProperty("shield", "RMT2");
            check(TierApi.normalize(retired, "AXIMITY").getAsJsonObject("rankings").getAsJsonObject("shield").get("retired").getAsBoolean(), "Retired MT parsing");
            cfg.primaryUrl = "ftp://example.com"; try { cfg.validate(); throw new AssertionError("Invalid scheme"); } catch (IllegalArgumentException expected) {}
            if (args.length > 1) {
                ApiConfig liveConfig = new ApiConfig(); liveConfig.backupEnabled = false;
                TierApi liveApi = new TierApi(client, liveConfig);
                JsonObject identity = liveApi.resolveName("AXIMITY").get(15, TimeUnit.SECONDS);
                check(identity.get("id").getAsString().equals(aximity.get("uuid").getAsString()), "Live Mojang UUID");
                verifyLiveProfile(liveApi.lookup(identity.get("id").getAsString(), "AXIMITY").get(35, TimeUnit.SECONDS));
                System.out.println("LIVE_PRIMARY_AND_MOJANG_PASSED");
            }
            System.out.println("TIER_API_TESTS_PASSED");
        } finally { server.stop(0); }
    }
}
